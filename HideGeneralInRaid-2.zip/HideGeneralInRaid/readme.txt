
Hide General In Raid

Hides the general chat channel when you're inside a raid dungeon

*** Changelog

Version 2
 * Removed debug output
