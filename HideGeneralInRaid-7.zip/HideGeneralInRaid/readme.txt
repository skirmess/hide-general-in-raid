
Hide General In Raid

Hides the general chat channel when you're inside a raid dungeon

*** Changelog

Version 6
 * Updated TOC for WoW 5.4.0
 * CHAT_MSG_CHANNEL_NOTICE is no longer fired if you enter or leave an instance eventhought the general channel changes to the instance channel. We will now change the channel on PLAYER_ENTERING_WORLD, which is fired for every loading screen. The addon will no longer update the visibility of the General channel if you manually leave or join the channel until the next loading screen.

Version 6
 * Updated TOC for WoW 5.2.0

Version 5
 * Updated for MoP.

Version 4
 * Updated TOC for WoW 4.3.0

Version 3
 * Updated TOC for WoW 4.0.1

Version 2
 * Removed debug output
