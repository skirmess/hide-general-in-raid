
Hides the general chat channel when you're inside a raid dungeon

