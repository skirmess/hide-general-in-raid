
Hide General In Raid

Hides the general chat channel when you're inside a raid dungeon

*** Changelog

Version 3
 * Updated TOC for WoW 4.0.1

Version 2
 * Removed debug output
